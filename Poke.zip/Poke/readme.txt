Name: Multiplayer Poker With AI
This game will feature multiple players and an AI in a game of poker, and the game ends when everyone except one player folds or the player with the highest valued deck wins When it is the player’s turn, press ‘b’ to bet a specific amount, the amount must be greater than or equal to the current highest bet. Press ’s’ to match the previous amount. Press ‘a’ to go “all-in” and bet all your money. Press ‘f’ to fold your cards
How to Run:
To run the project, the “Poker.py” file should be run
I am using random, string, time and I am using cmu_112_graphics
Shortcuts: Press ‘r’ to restart the game
